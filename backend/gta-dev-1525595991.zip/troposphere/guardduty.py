# Copyright (c) 2012-2017, Mark Peek <mark@peek.org>
# All rights reserved.
#
# See LICENSE file for full license.

from . import AWSObject
from .validators import boolean


class Detector(AWSObject):
    resource_type = 'AWS::GuardDuty::Detector'

    props = {
        'Enable': (boolean, True),
    }


class IPSet(AWSObject):
    resource_type = 'AWS::GuardDuty::IPSet'

    props = {
        'Activate': (boolean, True),
        'DetectorId': (str, True),
        'Format': (str, True),
        'Location': (str, True),
        'Name': (str, False),
    }


class Master(AWSObject):
    resource_type = "AWS::GuardDuty::Master"

    props = {
        'DetectorId': (str, True),
        'InvitationId': (str, True),
        'MasterId': (str, True),
    }


class Member(AWSObject):
    resource_type = "AWS::GuardDuty::Member"

    props = {
        'DetectorId': (str, True),
        'Email': (str, True),
        'MemberId': (str, True),
        'Message': (str, False),
        'Status': (str, False),
    }


class ThreatIntelSet(AWSObject):
    resource_type = 'AWS::GuardDuty::ThreatIntelSet'

    props = {
        'Activate': (boolean, True),
        'DetectorId': (str, True),
        'Format': (str, True),
        'Location': (str, True),
        'Name': (str, False),
    }
